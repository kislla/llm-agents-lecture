// LinkedIn job search results — bulk extraction (live-tested 2026-06).
//
// HOW TO USE (the constraints below were discovered on a real run — respect them):
//
// 1. The browser JS tool does NOT support top-level await, and async
//    continuations DIE when the call returns. Everything must be synchronous.
// 2. LinkedIn's results list is VIRTUALIZED: cards far from the viewport are
//    de-rendered (id present, content empty). No single extraction pass can
//    see all 25 jobs — you must scroll stepwise and extract+merge at each stop.
// 3. Programmatic scrolling (scrollIntoView / scrollTop) often does NOT
//    trigger hydration. Use REAL mouse-wheel scrolls (the computer tool's
//    scroll action over the results list, e.g. coordinate [480, 400],
//    5 ticks), which also looks human.
// 4. JS tool output is truncated (~1000 chars). Never return the jobs JSON
//    directly — it accumulates in window.__liAcc; read it out at the end in
//    ~950-char substring slices.
//
// STEP A — run this whole file once per results page (it's synchronous):
//   defines window.__liExtract() and resets window.__liAcc.
//
// STEP B — repeat until __liExtract() reports total == jobs on page (~25),
//   ideally in one batched tool call:
//     computer scroll down 5 ticks over the list -> wait 2s -> js: window.__liExtract()
//   Hydration can lag a scroll by a second or two; an extra wait+extract
//   round at the end usually catches stragglers.
//
// STEP C — read out:
//   js: window.__liOut = JSON.stringify(Object.values(window.__liAcc)); 'len='+window.__liOut.length
//   js: window.__liOut.substring(0, 950)   ... (950, 1900) ... etc.

window.__liAcc = {};

window.__liExtract = function () {
  const cardSelectors = [
    'li[data-occludable-job-id]',                 // logged-in jobs search (current)
    'li.jobs-search-results__list-item',           // older logged-in
    'div.job-card-container[data-job-id]',         // card container variant
    'ul.jobs-search__results-list > li',           // logged-out public
  ];
  let cards = [];
  for (const sel of cardSelectors) {
    cards = Array.from(document.querySelectorAll(sel));
    if (cards.length) break;
  }
  const pick = (root, sels) => {
    for (const s of sels) {
      const el = root.querySelector(s);
      if (el && el.innerText && el.innerText.trim()) return el.innerText.trim().replace(/\s+/g, ' ');
    }
    return '';
  };
  let captured = 0;
  cards.forEach((card) => {
    let id = card.getAttribute('data-occludable-job-id')
          || card.getAttribute('data-job-id')
          || (card.querySelector('[data-job-id]') ? card.querySelector('[data-job-id]').getAttribute('data-job-id') : '')
          || '';
    const a = card.querySelector('a[href*="/jobs/view/"]');
    if (!id && a) { const m = a.href.match(/\/jobs\/view\/(\d+)/); if (m) id = m[1]; }
    if (!id) return;

    const title = pick(card, [
      '.job-card-list__title--link strong',
      '.job-card-list__title--link',
      'a.job-card-container__link strong',
      'a.job-card-container__link',
      '.base-search-card__title',
    ]) || (a ? a.innerText.trim().replace(/\s+/g, ' ') : '');
    if (!title) return; // card not hydrated at this scroll position — later pass will catch it

    const company = pick(card, [
      '.artdeco-entity-lockup__subtitle',
      '.job-card-container__primary-description',
      '.job-card-container__company-name',
      '.base-search-card__subtitle',
    ]);
    const location = pick(card, [
      '.job-card-container__metadata-wrapper li',
      '.job-card-container__metadata-item',
      '.artdeco-entity-lockup__caption',
      '.job-search-card__location',
    ]);
    const timeEl = card.querySelector('time');
    const postedDatetime = timeEl ? (timeEl.getAttribute('datetime') || '') : '';
    // innerText can include a second line like "Within the past 24 hours" — keep first line only
    let postedRaw = timeEl ? timeEl.innerText.trim()
                  : pick(card, ['.job-card-container__listed-time', '.job-search-card__listdate']);
    postedRaw = (postedRaw || '').split('\n')[0].trim();
    const easyApply = /easy apply/i.test(card.innerText || '');

    if (!window.__liAcc[String(id)]) {
      window.__liAcc[String(id)] = {
        id: String(id), title, company, location, postedRaw, postedDatetime, easyApply,
        link: 'https://www.linkedin.com/jobs/view/' + id + '/',
      };
      captured++;
    }
  });
  return 'new=' + captured + ', total=' + Object.keys(window.__liAcc).length + ', cardsInDom=' + cards.length;
};

'extractor installed: ' + Object.keys(window.__liAcc).length;
