# Playwright MCP fallback

Use this only when Claude in Chrome is unavailable. The flow is identical to
SKILL.md — only the tool names change.

## Requirements

A Playwright MCP server (e.g., `@playwright/mcp`) configured to use the
user's **real Chrome profile** so their LinkedIn login carries over:

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest", "--browser=chrome", "--user-data-dir=<their Chrome profile dir>"]
    }
  }
}
```

If the server launches a fresh profile instead, the user will hit a login
wall. Don't ask for their password — ask them to either reconfigure the MCP
with their profile dir, or log in manually once in the Playwright-controlled
window (the session then persists in that profile).

## Tool mapping

| SKILL.md step | Claude in Chrome | Playwright MCP (typical names) |
|---|---|---|
| Navigate | `navigate` | `browser_navigate` |
| Verify page | `get_page_text` / `read_page` | `browser_snapshot` |
| Bulk extract | `javascript_tool` | `browser_evaluate` (run `extraction.js`) |

`extraction.js` is an async IIFE returning a JSON string — pass it to
`browser_evaluate` as-is. Everything else (guardrails, pacing, pagination,
spreadsheet script) is unchanged.
