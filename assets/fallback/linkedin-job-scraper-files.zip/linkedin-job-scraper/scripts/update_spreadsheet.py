#!/usr/bin/env python3
"""Append scraped LinkedIn jobs to a master xlsx tracker, deduping by job ID.

Usage:
    python update_spreadsheet.py <jobs.json> <master.xlsx> [--scrape-date YYYY-MM-DD]

jobs.json: array of objects with keys:
    id, title, company, location, postedRaw, postedDatetime, easyApply, link
    and optionally searchQuery.

Creates the xlsx (with formatting) if it doesn't exist. Never touches the
user-owned Status / Notes columns on existing rows. Prints a JSON summary.
"""
import json
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("openpyxl is required: pip install openpyxl --break-system-packages")

COLUMNS = [
    ("Job ID", 14), ("Company", 28), ("Job Title", 42), ("Location", 26),
    ("Workplace Type", 15), ("Easy Apply", 11), ("Posted Date", 13),
    ("Posted (raw)", 16), ("Job Link", 46), ("Search Query", 28),
    ("Date Scraped", 13), ("Status", 16), ("Notes", 40),
]

WORKPLACE_RE = re.compile(r"\((Remote|Hybrid|On[- ]?site)\)", re.IGNORECASE)
RELATIVE_RE = re.compile(
    r"(?:reposted\s+)?(\d+)\s+(minute|hour|day|week|month|year)s?\s+ago", re.IGNORECASE
)

def split_location(location: str):
    """'Toronto, ON (Hybrid)' -> ('Toronto, ON', 'Hybrid')"""
    if not location:
        return "", ""
    m = WORKPLACE_RE.search(location)
    if not m:
        return location.strip(), ""
    wt = m.group(1).replace(" ", "-").title().replace("Site", "site")
    loc = WORKPLACE_RE.sub("", location).strip().rstrip(",").strip()
    return loc, wt

def resolve_posted_date(posted_datetime: str, posted_raw: str, scrape_date: date):
    """Prefer the absolute datetime attribute; else convert relative text."""
    if posted_datetime:
        try:
            return datetime.fromisoformat(posted_datetime.replace("Z", "")).date().isoformat()
        except ValueError:
            pass
    if posted_raw:
        m = RELATIVE_RE.search(posted_raw)
        if m:
            n, unit = int(m.group(1)), m.group(2).lower()
            days = {"minute": 0, "hour": 0, "day": 1, "week": 7, "month": 30, "year": 365}[unit]
            return (scrape_date - timedelta(days=n * days)).isoformat()
        if re.search(r"just now|today", posted_raw, re.IGNORECASE):
            return scrape_date.isoformat()
        if re.search(r"yesterday", posted_raw, re.IGNORECASE):
            return (scrape_date - timedelta(days=1)).isoformat()
    return ""

def create_workbook(path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Jobs"
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(bold=True, color="FFFFFF")
    for col, (name, width) in enumerate(COLUMNS, 1):
        cell = ws.cell(row=1, column=col, value=name)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLUMNS))}1"
    wb.save(path)
    return wb

def main():
    argv = sys.argv[1:]
    scrape_date = date.today()
    args = []
    i = 0
    while i < len(argv):
        if argv[i] == "--scrape-date":
            scrape_date = date.fromisoformat(argv[i + 1])
            i += 2
        else:
            args.append(argv[i])
            i += 1
    if len(args) != 2:
        sys.exit(__doc__)
    jobs_path, xlsx_path = Path(args[0]), Path(args[1])

    jobs = json.loads(jobs_path.read_text())

    if xlsx_path.exists():
        wb = load_workbook(xlsx_path)
        ws = wb["Jobs"] if "Jobs" in wb.sheetnames else wb.active
    else:
        xlsx_path.parent.mkdir(parents=True, exist_ok=True)
        wb = create_workbook(xlsx_path)
        ws = wb.active

    existing_ids = {
        str(ws.cell(row=r, column=1).value)
        for r in range(2, ws.max_row + 1)
        if ws.cell(row=r, column=1).value is not None
    }

    added, skipped = 0, 0
    link_font = Font(color="0563C1", underline="single")
    for job in jobs:
        jid = str(job.get("id", "")).strip()
        if not jid:
            continue
        if jid in existing_ids:
            skipped += 1
            continue
        existing_ids.add(jid)
        loc, wt = split_location(job.get("location", ""))
        posted = resolve_posted_date(
            job.get("postedDatetime", ""), job.get("postedRaw", ""), scrape_date
        )
        row = ws.max_row + 1
        values = [
            jid, job.get("company", ""), job.get("title", ""), loc, wt,
            "Yes" if job.get("easyApply") else "No", posted,
            job.get("postedRaw", ""), job.get("link", ""),
            job.get("searchQuery", ""), scrape_date.isoformat(), "", "",
        ]
        for col, val in enumerate(values, 1):
            ws.cell(row=row, column=col, value=val)
        link_cell = ws.cell(row=row, column=9)
        link_cell.hyperlink = job.get("link", "")
        link_cell.font = link_font
        added += 1

    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLUMNS))}{ws.max_row}"
    wb.save(xlsx_path)

    print(json.dumps({
        "added": added,
        "duplicates_skipped": skipped,
        "total_in_sheet": ws.max_row - 1,
        "file": str(xlsx_path),
    }))

if __name__ == "__main__":
    main()
